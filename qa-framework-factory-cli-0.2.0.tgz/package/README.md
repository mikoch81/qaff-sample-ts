# QA Framework Factory CLI

Local package for the `qaff` command.

## Local package workflows

Build the CLI and copy packaged runtime assets:

```bash
npm run build
```

Link it into your local shell without publishing:

```bash
npm link
qaff --help
```

Create a local tarball without publishing:

```bash
npm pack
```

The packaged CLI includes the blueprint manifests it needs at runtime, so all commands below
work after local linking or local tarball installation.

## Shipped commands

### `qaff init`

Write a starter `qaff.config.yaml` in the current directory.

### `qaff validate-config`

Validate a config file against the schema without generating anything.

```bash
qaff validate-config --config ../examples/configs/multi-app-quality-impact.yaml
```

### `qaff list-blueprints`

List all discovered blueprints.

```bash
qaff list-blueprints
qaff list-blueprints --json
```

### `qaff create`

Generate a full framework project from a config file.

```bash
qaff create --config qaff.config.yaml --output ./generated
qaff create --config qaff.config.yaml --output ./generated --force      # overwrite
qaff create --config qaff.config.yaml --output ./generated --dry-run    # plan only
qaff create --config qaff.config.yaml --output ./generated --java 17    # Java 17 compat
```

### `qaff verify`

Validate the structural integrity of an already-generated project.

```bash
qaff verify --project ./generated
qaff verify --project ./generated --json
qaff verify --project ./generated --write-report
qaff verify --project ./generated --run-maven    # also runs mvn -B verify
```

### `qaff doctor`

Check local machine readiness (Node, Java, Maven, browser, Git).

```bash
qaff doctor
qaff doctor --json
qaff doctor --project ./generated    # also runs lightweight project checks
```

### `qaff add-app`

Add a new application module to an already-generated project.

```bash
qaff add-app --project ./generated --app new-portal
qaff add-app --project ./generated --app new-portal --quality-impact    # include QI layers
qaff add-app --project ./generated --app new-portal --dry-run
```

### `qaff remove-app`

Remove an existing application module from an already-generated project.

```bash
qaff remove-app --project ./generated --app demo-saas --dry-run
qaff remove-app --project ./generated --app demo-saas
```

### `qaff add-layer`

Extend an existing application with additional layers.

```bash
qaff add-layer --project ./generated --app demo-portal --layers api --quality-impact
qaff add-layer --project ./generated --app demo-saas --layers api,integration,performance --quality-impact
qaff add-layer --project ./generated --app demo-portal --layers api --quality-impact --dry-run
```

### `qaff update-app`

Reconcile an existing application by creating missing generated files. By default,
existing files are preserved. Use `--force` to overwrite existing app files
deterministically. Use `--paths` to limit reconciliation to selected app-relative
path prefixes.

```bash
qaff update-app --project ./generated --app demo-ecommerce
qaff update-app --project ./generated --app demo-ecommerce --dry-run
qaff update-app --project ./generated --app demo-ecommerce --paths web-desktop/src/test --dry-run
qaff update-app --project ./generated --app demo-ecommerce --force
qaff update-app --project ./generated --app demo-ecommerce --paths web-desktop/pom.xml --force --dry-run
```

### `qaff evaluate-quality-impact`

Compare performance results against thresholds and baseline. Advisory by default;
`--strict` turns it into a hard gate (exits 1 on `OVER_THRESHOLD` or `REGRESSION`).

> **Prerequisite:** `framework-performance/reports/<app-id>.result.json` must exist
> for each performance app before running this command. Run the Gatling simulation
> (`mvn -Pgatling-smoke gatling:test`) or provide a fixture result file first.
> Without result files the command exits with an error.

```bash
qaff evaluate-quality-impact --project ./generated
qaff evaluate-quality-impact --project ./generated --json
qaff evaluate-quality-impact --project ./generated --strict --json
```

### `qaff update-baseline`

Promote accepted performance results into the project baseline (closes the
evaluate → accept → update loop).

> **Prerequisite:** `framework-performance/reports/<app-id>.result.json` must exist
> for each performance app before running this command. Run the Gatling simulation
> (`mvn -Pgatling-smoke gatling:test`) or provide a fixture result file first.
> Without result files the command exits with an error.

```bash
qaff update-baseline --project ./generated
qaff update-baseline --project ./generated --json
```

### `qaff analyze-failures`

Analyze local Allure results and render deterministic failure artifacts:

- `failure-summary.md`
- `failure-analysis.json` (`qaff/allure-failure-analysis/v1`)
- `failure-analysis.md`
- optional `failure-analysis.request.json` (`--write-request`)
- project multi-layer aggregate: `apps/<app-id>/reports/failure-analysis/summary.{json,md}`
- project cross-app aggregate: `reports/failure-analysis/summary.{json,md}`

Project mode flags:

- `--all-layers` or `--layers <layer1,layer2>` for multi-layer analysis
- `--all-apps` or `--apps <app1,app2>` for cross-app analysis (requires multi-layer flags)
- `--ai` to enable optional AI analysis in project mode
- `--ai-provider <id>`, `--ai-timeout-ms <n>`, `--ai-max-cost-usd <n>` to tune AI behavior

AI policy profiles can also be stored in `qa-factory.lock.json` under `failureAnalysisAi` (global policy + `appOverrides`).
When `--ai` is enabled, resolution order is:

1. CLI flags (`--ai-provider`, `--ai-timeout-ms`, `--ai-max-cost-usd`)
2. app override from lock (`failureAnalysisAi.appOverrides[]`)
3. lock global policy (`failureAnalysisAi`)
4. built-in defaults (`noop`, `1500ms`, `0.5 USD`)

AI mode is opt-in. Without `--ai`, outputs remain deterministic and unchanged. With `--ai`, any timeout,
provider error, invalid response shape, or cost-limit breach falls back to deterministic analysis and
adds an `AI_FALLBACK_*` warning in `failure-analysis.json`.

AI policy profiles can be configured from YAML and are normalized into the generated lock file:

```yaml
ai:
  enabled: true
  analyzeFailures:
    enabled: true
    provider: noop
    timeoutMs: 1500
    maxCostUsd: 0.5
    appOverrides:
      - appId: demo-saas
        timeoutMs: 2500
        maxCostUsd: 0.25
      - appId: demo-logistics
        provider: mock
        timeoutMs: 1000
        maxCostUsd: 0.05
```

Use [`../examples/configs/multi-app-ai-policy-profiles.yaml`](../examples/configs/multi-app-ai-policy-profiles.yaml)
as the runnable example. `noop` is the safe built-in provider and always keeps the deterministic path.
`mock` is a local deterministic/demo provider used for tests and examples. External provider integrations,
secrets, hosted runtimes, CI comments, and external writeback remain future scope.

Policy fields:

| Field | Meaning | Default / rule |
| --- | --- | --- |
| `enabled` | Stores an explicit policy toggle in the lock file. Runtime AI still requires `--ai`. | `false` |
| `provider` | Provider id to resolve when `--ai` is enabled. | `noop` |
| `timeoutMs` | Timeout budget per provider call, per analyzed layer. | `1500`, must be positive |
| `maxCostUsd` | Local estimated-cost ceiling for one provider response. It is not billing integration. | `0.5`, must be non-negative |
| `appOverrides[]` | Per-app overrides by `appId`; omitted fields inherit from the global policy. | matched by app id |

```bash
# file mode
qaff analyze-failures \
	--input ./generated/apps/demo-ecommerce/web-desktop/target/allure-results \
	--output ./generated/apps/demo-ecommerce/reports/failure-analysis

# project mode
qaff analyze-failures --project ./generated --app demo-ecommerce

# machine-readable summary
qaff analyze-failures --project ./generated --app demo-ecommerce --json

# project mode (single app + multi-layer)
qaff analyze-failures --project ./generated --app demo-ecommerce --all-layers

# project mode (cross-app + multi-layer)
qaff analyze-failures --project ./generated --all-apps --all-layers --json
qaff analyze-failures --project ./generated --apps demo-ecommerce,demo-admin --layers web-desktop,api

# project mode with AI opt-in (mock provider shown as example)
qaff analyze-failures --project ./generated --app demo-ecommerce --all-layers --ai --ai-provider mock --ai-timeout-ms 1000 --ai-max-cost-usd 0.2

# include request sidecar
qaff analyze-failures --project ./generated --app demo-ecommerce --write-request
```

### `qaff update`

Inspect or apply update actions for an existing project. Exactly one mode is
required: `--dry-run` (read-only) or `--apply` (snapshot-aware writes). Use
`--all-apps` only with `--dry-run` to group readiness by application plus a
shared-files bucket.

```bash
qaff update --project ./generated --dry-run
qaff update --project ./generated --dry-run --all-apps
qaff update --project ./generated --dry-run --json
qaff update --project ./generated --dry-run --all-apps --json
qaff update --project ./generated --apply
qaff update --project ./generated --apply --merge-conflicts
qaff update --project ./generated --apply --accept-renderer
qaff update --project ./generated --apply --paths README.md,apps/demo-ecommerce
qaff update --project ./generated --apply --json
```

`--merge-conflicts` attempts a conservative line-based merge for text conflict
candidates and falls back to `.qaff-new` sidecars when the base is unavailable or
edits overlap. `--accept-renderer` remains the explicit overwrite mode.
